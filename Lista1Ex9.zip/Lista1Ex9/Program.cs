﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1Ex9
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double valor;
            double resultado;

            Console.WriteLine("digite o valor do diâmetro do círculo: ");
            valor = double.Parse(Console.ReadLine());

            resultado = Math.PI * Math.Pow((valor / 2), 2);

            Console.WriteLine("resultado: {0}",resultado);
        }
    }
}
