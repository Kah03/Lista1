﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1Ex7
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double valor;
            double resultado;

            Console.WriteLine("digite um valor em milha marítima: ");
            valor = double.Parse(Console.ReadLine());

            resultado = valor * 1.853;

            Console.WriteLine("resultado em quilômetro: {0}", resultado);
        }
    }
}
