﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1Ex4
{
    internal class Program
    {
        private static object consol;

        static void Main(string[] args)
        {
            double basen;
            double altura;
            double resultado;


            Console.WriteLine("digite o valor da base: "); 
            basen = double.Parse(Console.ReadLine());

            Console.WriteLine("digite o valor da altura: ");
            altura = double.Parse(Console.ReadLine());

            resultado = (basen * altura)/2;
            Console.WriteLine("Resultado: {0}", resultado);
         
        }
    }
}
