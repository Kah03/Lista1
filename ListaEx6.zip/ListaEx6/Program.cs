﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListaEx6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double valor1; 
            double valor2;
            double resultado;

            Console.WriteLine("digite o primeiro valor: "); 
            valor1 = double.Parse(Console.ReadLine());

            Console.WriteLine("digite o valor dois: ");
            valor2 = double.Parse(Console.ReadLine());

            resultado = valor1 * valor2; 
            resultado = Math.Sqrt(resultado);

            Console.WriteLine("resultado: {0} ", resultado);
           

          

         

        }
    }
}
