﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1Ex10
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double valordolar;
            double valorcotacao;
            double resultado;

            Console.WriteLine("digite o valor da cotação do dólar: R$ ");
            valocotacao = double.Parse(Console.ReadLine());

            Console.WriteLine("digite um valor em dólares: US$ "); 
            valordolar = double.Parse(Console.ReadLine());

            resultado = valordolar * valorcotacao; 

            Console.WriteLine("resultado em reais; {0}", resultado.ToString("c"));
        }
    }
}
