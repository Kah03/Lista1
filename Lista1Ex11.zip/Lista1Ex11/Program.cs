﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1Ex11
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double basen;
            double expoente;
            double resultado;

            Console.WriteLine("digite o valor da base: ");
            basen = double.Parse(Console.ReadLine());

            Console.WriteLine("digite o valor do expoente: ");
            expoente = double.Parse(Console.ReadLine());

            resultado = Math.Pow(basen,expoente);

            Console.WriteLine("resultado em reais: {0}", resultado);
        }
    }
