﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1_Ex1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double basen;
            double altura;
            double resultado;

            Console.WriteLine("digite o valor da base: ");
            basen = double.Parse(Console.ReadLine());
            
            Console.WriteLine("digite o valor da altura: ");
            altura = double.Parse(Console.ReadLine());


            resultado = basen * altura;
            Console.WriteLine("resultado é: {0}",resultado);


        }
    }
}
