﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1Ex12
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double valorp1;
            double valorp2;
            double valorp3;
            double valorp4;
            double valorp5;
            double pagamento;
            double troco;

            Console.WriteLine("digite o valor do primeiro produto: R$");
            valorp1 = double.Parse(Console.ReadLine());

            Console.WriteLine("digite o valor do segundo produto: R$");
            valorp2 = double.Parse(Console.ReadLine());

            Console.WriteLine("digite o valor do terceiro produto: R$");
            valorp3 = double.Parse(Console.ReadLine());

            Console.WriteLine("digite o valor do quarto produto: R$");
            valorp4 = double.Parse(Console.ReadLine());

            Console.WriteLine("digite o valor do quinto produto: R$");
            valorp5 = double.Parse(Console.ReadLine()); 

            Console.WriteLine("digite o valor do pagamento: R$");
            pagamento = double.Parse(Console.ReadLine());

            troco = pagamento -(valorp1 + valorp2 + valorp3 + valorp4 + valorp5);

            Console.WriteLine("troco: {0}", troco.ToString("C"));

        }
    }
}
