﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1Ex8
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double valor;
            double resultado;

            Console.WriteLine("digite um valor em Graus Celsius: "); 
            valor = double.Parse(Console.ReadLine());

            resultado = (valor * 1, 8) + 32;

            Console.WriteLine("resultado em fahrenheit: {0}", resultado);
        
    }
}
